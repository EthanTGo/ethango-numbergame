<img src='images/ethango-numbergame.jpg' width=700 height=500>

# About the project

This is the ethango-numbergame! A number guessing game that is made by Ethan Go. This is a very fun project that I have been working on primarily to understand and apply a lot of the concepts I learn from my software engineering course. I hope you enjoy the game.

The basic purpose of this project is to create a simple game and practice good OOP (Object Oriented Programming) practices. I am also applying good documentation on each code and function to make this project easy to follow through.

# Getting started 

This project should be uploaded on the PyPi. To install it simply do...

To run the files on the repository, you would need to install pytest for the test file. Installation for pytest can be found <a href="https://docs.pytest.org/en/stable/getting-started.html">here</a>: !

# License

Distributed under the MIT License. See license.txt for more information.

# Contact 

Ethan Go - ethango1997@gmail.com

Project Link: https://github.com/EthanTGo/ethango-numbergame
