from setuptools import setup


setup(
    name = "ethango_numbergame",
    version = 0.1,
    description = "Number guessing game",
    packages = ["ethango_numbergame"],
    zip_safe = False
)
